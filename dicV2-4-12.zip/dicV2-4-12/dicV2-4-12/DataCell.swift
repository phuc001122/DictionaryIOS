//
//  DataCell.swift
//  dicV2-4-12
//
//  Created by CNTT-MAC on 12/4/17.
//  Copyright © 2017 CNTT-MAC. All rights reserved.
//

import UIKit

class DataCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
