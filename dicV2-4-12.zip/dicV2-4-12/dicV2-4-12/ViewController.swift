//
//  ViewController.swift
//  dicV2-4-12
//
//  Created by CNTT-MAC on 12/4/17.
//  Copyright © 2017 CNTT-MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

