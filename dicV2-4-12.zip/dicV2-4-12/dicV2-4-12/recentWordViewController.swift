//
//  recentWordViewController.swift
//  dicV2-4-12
//
//  Created by CNTT-MAC on 12/4/17.
//  Copyright © 2017 CNTT-MAC. All rights reserved.
//

import UIKit

class recentWordViewController: UIViewController, UITableViewDataSource, UISearchBarDelegate, UITableViewDelegate {

    
    @IBOutlet weak var recentTableView: UITableView!
    @IBOutlet weak var searchWord: UISearchBar!
    
    var mang = ["iPhone","macOS","TV Watch","Apple Watch"]
    
    var filteredData = [String]()
    
    var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        recentTableView.delegate = self
        recentTableView.dataSource = self
        searchWord.delegate = self
        searchWord.returnKeyType = UIReturnKeyType.done
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if isSearching
        {
            return filteredData.count
        }
        
        return mang.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "DataCell", for: <#T##IndexPath#>) as? DataCell
        {
            let text: String!
            if isSearching
            {
                text = filteredData[indexPath.row]
            }
            else
            {
                text = mang[indexPath.row]
            }
            cell.configureCell(data: text)
            return cell
        }
        else
        {
            return UITableViewCell()
        }
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchBar.text == nil || searchBar.text == ""
        {
            isSearching = false
            view.endEditing(true)
            recentTableView.reloadData()
        }
        else
        {
            isSearching = true
            filteredData = mang.filter({$0 == searchBar.text})
            recentTableView.reloadData()
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
